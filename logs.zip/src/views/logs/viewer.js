// Global variables and state
let evtSource = null;
let isStreaming = false;
let reconnectDelay = 1000;
const maxReconnectDelay = 30000;
const logContainer = document.getElementById('logContainer');
const streamingStatus = document.getElementById('streamingStatus');
const startStreamingBtn = document.getElementById('startStreaming');
const stopStreamingBtn = document.getElementById('stopStreaming');
const logCountDisplay = document.getElementById('logCount');
let logCount = 0;

// Audit trail functionality
let auditEntries = [];
const MAX_AUDIT_ENTRIES = 100;
const auditTrailContainer = document.getElementById('auditTrailContainer');

// Current user information - hardcoded for now
const currentUser = {
  id: 'n057',
  name: 'John Smith',
  username: 'jsmith',
  roles: ['user'],
  files: [],
};

/**
 * Main initialization function - called when DOM is loaded
 */
function initLogViewer() {
  console.log('DOM loaded, initializing log viewer');
  
  // Setup UI context filter option
  setupUIContextFilter();
  
  // Setup event handlers for all buttons and controls
  setupEventHandlers();
  
  // Setup UI tracking
  setupUITracking();
  
  // Initialize modules
  updateSystemStatus();
  updateRecentActivity();
  updateCurrentUserModule();
  
  // Load initial logs
  fetchLogs();
  
  // Start streaming logs
  startStreaming();
  
  // Load initial audit trail data
  loadInitialAuditData();
  
  // Set up auto refresh based on current time range
  setupAutoRefresh();
  
  // Update modules periodically
  setInterval(() => {
    updateSystemStatus();
    updateRecentActivity();
    updateCurrentUserModule();
  }, 30000);

  // Add test buttons for log levels
  addTestLogButtons();
}

/**
 * Setup all event handlers for the log viewer controls
 */
function setupEventHandlers() {
  // Automatic refresh on filter dropdown change
  document.querySelectorAll('.auto-refresh').forEach(filter => {
    filter.addEventListener('change', () => {
      fetchLogs();
      // If streaming is active, restart it with the new filters
      if (isStreaming) {
        stopStreaming();
        startStreaming();
      }
    });
  });
  
  // Search pattern input - refresh on enter key
  const patternInput = document.getElementById('pattern');
  if (patternInput) {
    patternInput.addEventListener('keyup', (event) => {
      if (event.key === 'Enter') {
        fetchLogs();
        // Also restart streaming with new filters if active
        if (isStreaming) {
          stopStreaming();
          startStreaming();
        }
      }
    });
  }

  // Manual refresh button
  const refreshLogsBtn = document.getElementById('refreshLogs');
  if (refreshLogsBtn) {
    refreshLogsBtn.addEventListener('click', () => {
      fetchLogs();
      // Restart streaming with new filters
      if (isStreaming) {
        stopStreaming();
        startStreaming();
      }
    });
  }

  // Clear logs button
  const clearLogsBtn = document.getElementById('clearLogs');
  if (clearLogsBtn) {
    clearLogsBtn.addEventListener('click', () => {
      logContainer.innerHTML = '';
      logCount = 0;
      updateLogCount();
    });
  }

  // Info log trigger button
  const triggerInfoLogBtn = document.getElementById('triggerInfoLog');
  if (triggerInfoLogBtn) {
    triggerInfoLogBtn.addEventListener('click', async () => {
      try {
        const memoryInfo = window.performance.memory || {
          usedJSHeapSize: 'N/A',
          totalJSHeapSize: 'N/A',
          jsHeapSizeLimit: 'N/A',
        };

        const systemInfo = {
          memory: {
            usedJSHeapSize: `${(memoryInfo.usedJSHeapSize / 1024 / 1024).toFixed(2)} MB`,
            totalJSHeapSize: `${(memoryInfo.totalJSHeapSize / 1024 / 1024).toFixed(2)} MB`,
            jsHeapSizeLimit: `${(memoryInfo.jsHeapSizeLimit / 1024 / 1024).toFixed(2)} MB`,
          },
          userAgent: navigator.userAgent,
        };

        await fetch('/logs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            level: 'INFO',
            message: `Browser Performance Info: ${JSON.stringify(systemInfo)}`,
          }),
        });
        console.log('Performance info log triggered');
      } catch (error) {
        console.error('Failed to trigger performance info log:', error);
      }
    });
  }

  // Error log trigger button
  const triggerErrorLogBtn = document.getElementById('triggerErrorLog');
  if (triggerErrorLogBtn) {
    triggerErrorLogBtn.addEventListener('click', async () => {
      try {
        const errorEvent = {
          type: 'SystemError',
          timestamp: new Date().toISOString(),
          details: {
            code: 'E500',
            description: 'Simulated server error for testing purposes',
            stack: 'Error: Simulated error\n    at triggerErrorLog (viewer.js:123)',
          },
        };

        await fetch('/logs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            level: 'ERROR',
            message: `System Error Event: ${JSON.stringify(errorEvent)}`,
          }),
        });
        console.log('Error log triggered');
      } catch (error) {
        console.error('Failed to trigger error log:', error);
      }
    });
  }

  // Image upload button
  const uploadImageBtn = document.getElementById('uploadImage');
  if (uploadImageBtn) {
    uploadImageBtn.addEventListener('click', () => handleImageUpload());
  }

  // Log container click for log details
  if (logContainer) {
    logContainer.addEventListener('click', (event) => {
      const logElement = event.target.closest('.log-entry');
      if (logElement) {
        const logDetails = logElement.innerHTML;
        showLogOverlay(logDetails);
      }
    });
  }

  // Expand/collapse audit trail
  const expandAuditTrailBtn = document.getElementById('expandAuditTrail');
  if (expandAuditTrailBtn) {
    expandAuditTrailBtn.addEventListener('click', function () {
      const auditTrail = document.querySelector('.audit-trail-container');
      if (!auditTrail) return;

      if (auditTrail.classList.contains('audit-trail-expanded')) {
        // Collapse
        auditTrail.classList.remove('audit-trail-expanded');
        expandAuditTrailBtn.textContent = 'Expand';
      } else {
        // Expand
        auditTrail.classList.add('audit-trail-expanded');
        expandAuditTrailBtn.textContent = 'Collapse';
      }
    });
  }

  // Clear audit trail
  const clearAuditTrailBtn = document.getElementById('clearAuditTrail');
  if (clearAuditTrailBtn && auditTrailContainer) {
    clearAuditTrailBtn.addEventListener('click', function () {
      auditTrailContainer.innerHTML = '';
      auditEntries = [];
    });
  }

  // Time range change
  const timeRangeSelect = document.getElementById('timeRange');
  if (timeRangeSelect) {
    timeRangeSelect.addEventListener('change', () => {
      fetchLogs();
      setupAutoRefresh();
      refreshAuditTrail();
    });
  }
  
  // Handle visibility changes
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden' && isStreaming) {
      const wasStreaming = true;
      stopStreaming();
      isStreaming = wasStreaming;
    } else if (document.visibilityState === 'visible' && isStreaming) {
      startStreaming();
    }
  });
  
  // Handle page unload
  window.addEventListener('beforeunload', () => {
    if (evtSource) {
      evtSource.close();
    }
  });
}

/**
 * Setup UI context filter in the context field
 */
function setupUIContextFilter() {
  const contextInput = document.getElementById('context');
  if (contextInput) {
    // Add datalist for context suggestions if it doesn't exist
    let contextList = document.getElementById('contextList');
    if (!contextList) {
      contextList = document.createElement('datalist');
      contextList.id = 'contextList';
      document.body.appendChild(contextList);
      contextInput.setAttribute('list', 'contextList');
    }

    // Add UI/UX option
    const uiOption = document.createElement('option');
    uiOption.value = 'UI/UX';
    contextList.appendChild(uiOption);
  }

  // Add UI/UX filter button
  const buttonRow = document.querySelector('.button-row');
  if (buttonRow) {
    const uiFilterBtn = document.createElement('button');
    uiFilterBtn.textContent = 'Show UI Events';
    uiFilterBtn.classList.add('ui-filter-btn');
    uiFilterBtn.addEventListener('click', () => {
      if (document.getElementById('context'))
        document.getElementById('context').value = 'UI/UX';
      fetchLogs();
    });
    buttonRow.appendChild(uiFilterBtn);
  }
}

/**
 * Load initial audit data
 */
function loadInitialAuditData() {
  fetch('/logs')
    .then((response) => response.json())
    .then((logs) => {
      logs.forEach((log) => {
        // Only store logs that would qualify for audit trail
        if (shouldAddToAudit(log)) {
          auditEntries.push(log);
        }
      });

      // Apply initial time filtering to audit trail
      refreshAuditTrail();
    })
    .catch((error) =>
      console.error('Failed to load initial logs for audit:', error),
    );
}

/**
 * Handle image upload functionality
 */
function handleImageUpload() {
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = 'image/*';

  fileInput.addEventListener('change', async () => {
    const file = fileInput.files[0];
    if (!file) {
      console.warn('No file selected for upload.');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
      // Include user headers in the request
      const response = await fetch('/graphics', {
        method: 'POST',
        headers: {
          'x-user-id': currentUser.id,
          'x-username': currentUser.username,
          'x-session-id': `session-${Date.now()}`,
        },
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        console.log('Image uploaded successfully:', data);

        // Create a synthetic audit entry for the upload
        const syntheticAuditEntry = {
          id: `local-${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: currentUser.id,
          action: 'UPLOAD_GRAPHIC',
          status: 'success',
          resourceId: data.id,
          message: `File upload successful: ${file.name} (ID: ${data.id})`,
          level: 1, // INFO level
          context: 'FileUpload',
        };

        // Add the synthetic entry to audit entries
        auditEntries.unshift(syntheticAuditEntry);

        // Update both the user files and recent activity modules immediately
        updateCurrentUserModule();
        updateRecentActivity();

        alert(`Image uploaded successfully! ID: ${data.id}`);

        // Only check the graphic route after a successful upload
        checkGraphicsRoute(data.id);
      } else {
        const error = await response.text();
        console.error('Image upload failed:', error);
        alert(`Image upload failed: ${error}`);
      }
    } catch (error) {
      console.error('Error during image upload:', error);
      alert(`Error during image upload: ${error.message}`);
    }
  });

  fileInput.click();
}

// ----------- Logging Functions -----------

function formatLogLevel(level) {
  const levels = ['DEBUG', 'INFO', 'LOG', 'WARN', 'ERROR'];
  return levels[level] || String(level);
}

function formatLogEntry(log) {
  // First determine the base level class
  let levelClass = 'log-' + formatLogLevel(log.level).toLowerCase();
  
  // Then determine if we should apply a specialized context-based class
  const context = log.context || getDefaultContextLabel(log.level);
  
  // Apply specialized styling based on context
  if (context) {
    const contextLower = context.toLowerCase();
    if (contextLower.includes('performance') || 
        contextLower.includes('metrics') || 
        contextLower === 'metricsservice') {
      levelClass = 'log-performance';
    } else if (contextLower.includes('security') || 
               contextLower.includes('auth')) {
      levelClass = 'log-security';
    } else if (contextLower.includes('network') || 
              contextLower.includes('http') || 
              contextLower.includes('connection')) {
      levelClass = 'log-network';
    } else if (contextLower.includes('system')) {
      levelClass = 'log-system';
    } else if (contextLower.includes('user')) {
      levelClass = 'log-user';
    }
  }
  
  // Format timestamp and other properties as before
  const timestamp = new Date(log.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  let formattedMessage;
  if (typeof log.message === 'object') {
    const { type, details } = log.message || {};
    formattedMessage = `${type || 'Event'}: ${
      details?.description || 'No description provided'
    } (Code: ${details?.code || 'N/A'})`;
  } else {
    formattedMessage = String(log.message || '');
  }

  return `
    <div class="log-entry ${levelClass}">
      <span class="timestamp">[${timestamp}] [${formatLogLevel(log.level)}] [${context}]</span>
      <span class="message">${formattedMessage}</span>
    </div>
  `;
}

function getDefaultContextLabel(level) {
  switch (level) {
    case 0: // DEBUG
      return 'Debug Event';
    case 1: // INFO
      return 'Info Event';
    case 2: // LOG
      return 'Log Event';
    case 3: // WARN
      return 'Warning Event';
    case 4: // ERROR
      return 'Error Event';
    default:
      return 'General Event';
  }
}

function addLogEntry(log) {
  const logHtml = formatLogEntry(log);
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = logHtml.trim();
  const logElement = tempDiv.firstChild;

  // Add animation classes
  logElement.classList.add('new-log-entry');

  // Prepend to the top of the container instead of appending to the bottom
  logContainer.insertBefore(logElement, logContainer.firstChild);

  logCount++;
  updateLogCount();

  // Focus back to the top of the log container
  logContainer.scrollTop = 0;

  // Remove animation class after animation completes
  setTimeout(() => {
    logElement.classList.remove('new-log-entry');
  }, 300);

  // Trim logs if there are too many (remove from the bottom/oldest)
  if (logContainer.children.length > 1000) {
    logContainer.removeChild(logContainer.lastChild);
  }

  return logElement;
}

function updateLogCount() {
  if (logCountDisplay) {
    logCountDisplay.textContent = `${logCount} records`;
  }
}

// ----------- Log Fetching and Streaming Functions -----------

function fetchLogs() {
  const minLevel = document.getElementById('minLevel').value;
  const context = document.getElementById('context').value;
  const pattern = document.getElementById('pattern').value;
  const timeRange = document.getElementById('timeRange').value;

  let url = '/logs?';
  
  // Ensure minLevel is passed as a number parameter
  if (minLevel !== undefined && minLevel !== '') {
    url += 'level=' + parseInt(minLevel) + '&';
    console.log(`Filtering logs with minimum level: ${minLevel} (${formatLogLevel(parseInt(minLevel))})`);
  }
  if (context) {
    url += 'context=' + encodeURIComponent(context) + '&';
  }
  if (pattern) {
    url += 'pattern=' + encodeURIComponent(pattern) + '&';
  }
  if (timeRange) {
    const now = new Date();
    let fromDate;
    switch (timeRange) {
      case '5min':
        fromDate = new Date(now.getTime() - 5 * 60 * 1000);
        break;
      case 'hour':
        fromDate = new Date(now.getTime() - 60 * 60 * 1000);
        break;
      case 'day':
        fromDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        break;
      case 'week':
        fromDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        fromDate = new Date(now.setMonth(now.getMonth() - 1));
        break;
      case 'all':
      default:
        fromDate = null;
        break;
    }
    if (fromDate) {
      url += 'from=' + fromDate.toISOString() + '&';
    }
  }

  // Add a loading indicator to the log container
  const loadingIndicator = document.createElement('div');
  loadingIndicator.className = 'loading-indicator';
  loadingIndicator.textContent = 'Loading logs...';
  if (logContainer.firstChild) {
    logContainer.insertBefore(loadingIndicator, logContainer.firstChild);
  } else {
    logContainer.appendChild(loadingIndicator);
  }

  fetch(url)
    .then((response) => response.json())
    .then((logs) => {
      // Clear existing logs
      logContainer.innerHTML = '';
      logCount = 0;

      // Add logs in reverse order (newest first)
      logs.reverse().forEach((log) => {
        addLogEntry(log);
      });

      // Update log count display
      updateLogCount();
      
      // Update context dropdown with unique contexts from logs
      updateContextDropdown(logs);
    })
    .catch((error) => {
      console.error('Error fetching logs:', error);
      
      // Show error message in log container
      logContainer.innerHTML = `
        <div class="log-entry log-error">
          <span class="timestamp">[${new Date().toLocaleTimeString()}]</span>
          <span class="message">Error fetching logs: ${error.message}</span>
        </div>
      `;
    });
}

// Function to update the context dropdown with contexts from logs
function updateContextDropdown(logs) {
  const contextDropdown = document.getElementById('context');
  if (!contextDropdown) return;
  
  // Keep track of selected value to restore it
  const selectedValue = contextDropdown.value;
  
  // Get the first few context options which are static
  const staticOptions = Array.from(contextDropdown.options)
    .slice(0, 5)
    .map(opt => opt.value);
    
  // Extract unique contexts from logs
  const contexts = new Set(staticOptions);
  logs.forEach(log => {
    if (log.context && !staticOptions.includes(log.context)) {
      contexts.add(log.context);
    }
  });
  
  // Keep the existing options
  const currentOptions = new Set(Array.from(contextDropdown.options).map(opt => opt.value));
  
  // Add new contexts that aren't already in the dropdown
  contexts.forEach(context => {
    if (!currentOptions.has(context) && context) {
      const option = document.createElement('option');
      option.value = context;
      option.textContent = context;
      contextDropdown.appendChild(option);
    }
  });
  
  // Restore the previously selected value
  contextDropdown.value = selectedValue;
}

function startStreaming() {
  if (isStreaming) {
    return;
  }

  const minLevel = document.getElementById('minLevel')?.value || '0';
  const maxLevel = document.getElementById('maxLevel')?.value || '';
  const context = document.getElementById('context')?.value || '';
  const pattern = document.getElementById('pattern')?.value || '';

  let url = '/logs/stream?';
  if (minLevel) {
    url += 'level=' + minLevel + '&';
  }
  if (maxLevel) {
    url += 'maxLevel=' + maxLevel + '&';
  }
  if (context) {
    url += 'context=' + encodeURIComponent(context) + '&';
  }
  if (pattern) {
    url += 'pattern=' + encodeURIComponent(pattern);
  }

  console.log('Starting EventSource connection to:', url);
  evtSource = new EventSource(url);

  evtSource.onopen = (event) => {
    console.log('EventSource connection opened successfully');
  };

  evtSource.onmessage = (event) => {
    try {
      const log = JSON.parse(event.data);
      console.debug("Received log from stream:", log); // Debug the incoming log
      
      if ('level' in log) {
        const logElement = addLogEntry(log);
        if (logElement && log.id) {
          logElement.dataset.logId = log.id;
        }

        // Check if this should be in the audit trail
        addAuditEntry(log);
        
        // Force update of logCount display to ensure it's accurate
        updateLogCount();
      } else if (log.type === 'error') {
        console.error('Server error:', log.message);
      } else if (log.type === 'connected') {
        console.log('Server confirmed connection');
        // Display connection confirmation in the UI
        const statusIndicator = document.createElement('div');
        statusIndicator.className = 'log-entry log-info';
        statusIndicator.innerHTML = `
          <span class="timestamp">[${new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
          })}] [INFO] [LogStream]</span>
          <span class="message">Connected to log stream</span>
        `;
        logContainer.insertBefore(statusIndicator, logContainer.firstChild);
      }
      
      reconnectDelay = 1000;
    } catch (err) {
      console.error('Failed to process log message:', err, event.data);
    }
  };

  evtSource.onerror = (error) => {
    console.error('EventSource failed:', error);
    stopStreaming();
    if (document.visibilityState !== 'hidden') {
      setTimeout(() => {
        startStreaming();
      }, reconnectDelay);
      reconnectDelay = Math.min(reconnectDelay * 2, maxReconnectDelay);
    }
  };

  isStreaming = true;
  if (streamingStatus) {
    streamingStatus.textContent = 'Streaming Active';
    streamingStatus.classList.remove('streaming-inactive');
    streamingStatus.classList.add('streaming-active');
  }
  if (startStreamingBtn) {
    startStreamingBtn.classList.add('hidden');
  }
  if (stopStreamingBtn) {
    stopStreamingBtn.classList.remove('hidden');
  }
}

function stopStreaming() {
  if (evtSource) {
    evtSource.close();
    evtSource = null;
  }

  isStreaming = false;
  if (streamingStatus) {
    streamingStatus.textContent = 'Streaming Inactive';
    streamingStatus.classList.remove('streaming-active');
    streamingStatus.classList.add('streaming-inactive');
  }

  if (startStreamingBtn) {
    startStreamingBtn.classList.remove('hidden');
  }
  if (stopStreamingBtn) {
    stopStreamingBtn.classList.add('hidden');
  }
}

// ----------- Audit Trail Functions -----------

function addAuditEntry(log) {
  // Only create audit entries for important logs that match the time filter
  if (!shouldAddToAudit(log)) {
    return;
  }

  const auditEntry = createAuditEntryElement(log);

  // Add to the top of the audit trail
  if (auditTrailContainer) {
    auditTrailContainer.insertBefore(
      auditEntry,
      auditTrailContainer.firstChild,
    );

    // Store in our array (limited size)
    auditEntries.unshift(log);

    // Limit the number of entries in memory
    if (auditEntries.length > MAX_AUDIT_ENTRIES) {
      auditEntries.pop();
    }

    // Limit the DOM elements
    if (auditTrailContainer.children.length > MAX_AUDIT_ENTRIES) {
      auditTrailContainer.removeChild(auditTrailContainer.lastChild);
    }
  }
}

function shouldAddToAudit(log) {
  // First check if the log is within the selected time range
  const timeRange = document.getElementById('timeRange')?.value;
  if (!isLogWithinTimeRange(log, timeRange)) {
    return false;
  }

  // Always include errors and warnings
  if (log.level >= 3) {
    // WARN or ERROR
    return true;
  }

  // Include logs with specific contexts that indicate system operations
  const auditContexts = [
    'Security',
    'Authentication',
    'Authorization',
    'System',
    'User',
    'Data',
  ];
  if (log.context && auditContexts.some((ctx) => log.context.includes(ctx))) {
    return true;
  }

  // Include logs with message patterns indicating important operations
  const messageStr =
    typeof log.message === 'string' ? log.message : JSON.stringify(log.message);

  const auditPatterns = [
    /login/i,
    /logout/i,
    /upload/i,
    /delete/i,
    /error/i,
    /fail/i,
    /permission/i,
    /access/i,
    /modify/i,
    /change/i,
    /create/i,
    /unauthorized/i,
    /security/i,
    /reset/i,
    /password/i,
  ];

  return auditPatterns.some((pattern) => pattern.test(messageStr));
}

function isLogWithinTimeRange(log, timeRange) {
  if (!timeRange || timeRange === 'all') {
    return true; // No time filtering
  }

  const now = new Date();
  const logTimestamp = new Date(log.timestamp);

  switch (timeRange) {
    case '5min':
      return logTimestamp >= new Date(now.getTime() - 5 * 60 * 1000);
    case 'hour':
      return logTimestamp >= new Date(now.getTime() - 60 * 60 * 1000);
    case 'day':
      return logTimestamp >= new Date(now.getTime() - 24 * 60 * 60 * 1000);
    case 'week':
      return logTimestamp >= new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    case 'month': {
      const monthAgo = new Date(now);
      monthAgo.setMonth(monthAgo.getMonth() - 1);
      return logTimestamp >= monthAgo;
    }
    default:
      return true;
  }
}

function createAuditEntryElement(log) {
  const auditEntry = document.createElement('div');
  auditEntry.className = 'audit-entry';

  // Add specific class based on log level or content
  if (log.level === 4) {
    // ERROR
    auditEntry.classList.add('audit-error');
  } else if (log.level === 3) {
    // WARN
    auditEntry.classList.add('audit-warn');
  } else if (log.context && log.context.toLowerCase().includes('security')) {
    auditEntry.classList.add('audit-security');
  } else {
    auditEntry.classList.add('audit-info');
  }

  const timestamp = new Date(log.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  // Create condensed audit message
  let auditMessage = '';
  let fullMessage = '';

  if (typeof log.message === 'string') {
    // Extract the key action from the message
    fullMessage = log.message;
    auditMessage =
      log.message.length > 40
        ? log.message.substring(0, 40) + '...'
        : log.message;
  } else if (typeof log.message === 'object') {
    // For object messages, try to extract a useful summary
    const { type, action } = log.message || {};
    fullMessage = JSON.stringify(log.message, null, 2);
    auditMessage = type || action || 'Event';
    if (log.message && log.message.details) {
      auditMessage +=
        ': ' + JSON.stringify(log.message.details).substring(0, 30) + '...';
    }
  }

  // Store the full log data as a data attribute
  auditEntry.dataset.logId = log.id;

  // Mark entries with user info for special styling
  if (log.userId) {
    auditEntry.dataset.hasUser = 'true';
  }

  // Enhanced audit entry with compliance information when available
  let complianceInfo = '';
  if (log.userId || log.action || log.status) {
    complianceInfo = `<span class="audit-compliance">`;
    if (log.userId) complianceInfo += `User: ${log.userId.substring(0, 6)}.. `;
    if (log.action) complianceInfo += `${log.action} `;
    if (log.status) {
      const statusClass = `audit-${log.status}`;
      complianceInfo += `<span class="${statusClass}">[${log.status}]</span>`;
    }
    complianceInfo += `</span>`;
  }

  auditEntry.innerHTML = `
    <span class="audit-time">${timestamp}</span>
    <span class="audit-message" data-full-message="${escapeHtml(fullMessage)}">${auditMessage}</span>
    ${complianceInfo}
  `;

  // Add click handler to highlight corresponding log entry
  auditEntry.addEventListener('click', () => {
    // Find and highlight the full log entry
    highlightLogFromAudit(log.id);

    // Toggle selected state for this audit entry
    document.querySelectorAll('.audit-entry').forEach((el) => {
      el.classList.remove('audit-focused');
    });
    auditEntry.classList.add('audit-focused');
  });

  return auditEntry;
}

function refreshAuditTrail() {
  // Clear current audit trail
  if (!auditTrailContainer) return;

  auditTrailContainer.innerHTML = '';

  // Get current time range
  const timeRange = document.getElementById('timeRange')?.value;

  // Filter existing audit entries and re-add them
  const filteredEntries = auditEntries.filter((entry) =>
    isLogWithinTimeRange(entry, timeRange),
  );

  // Re-add filtered entries
  filteredEntries.forEach((entry) => {
    const auditEntry = createAuditEntryElement(entry);
    auditTrailContainer.appendChild(auditEntry);
  });

  // Sort entries by timestamp (newest first)
  Array.from(auditTrailContainer.children)
    .sort((a, b) => {
      const aId = a.dataset.logId;
      const bId = b.dataset.logId;
      const aEntry = auditEntries.find((entry) => entry.id === aId);
      const bEntry = auditEntries.find((entry) => entry.id === bId);

      if (!aEntry || !bEntry) return 0;

      return (
        new Date(bEntry.timestamp).getTime() -
        new Date(aEntry.timestamp).getTime()
      );
    })
    .forEach((node) => auditTrailContainer.appendChild(node));
}

// ----------- UI Update Functions -----------

function updateSystemStatus() {
  const systemStatusEl = document.getElementById('systemStatus');
  if (!systemStatusEl) return;

  const now = new Date();
  const timeString = now.toLocaleTimeString();

  // More compact status display
  systemStatusEl.innerHTML = `
    <div class="status-item"><strong>Time:</strong> ${timeString}</div>
    <div class="status-item"><strong>Status:</strong> ${navigator.onLine ? 'Online' : 'Offline'}</div>
    <div class="status-item"><strong>Logs:</strong> ${logCount}</div>
  `;
}

function updateRecentActivity() {
  const recentActivityEl = document.getElementById('recentActivity');
  if (!recentActivityEl) return;

  // Debug log to verify we're getting the most recent entries
  clientLog.debug(
    `Found ${auditEntries.length} total audit entries for recent activity`,
    'RecentActivity',
  );

  // Get the most recent entries including synthetic ones
  const recent = auditEntries.slice(0, 5); // Increase to get more entries

  if (recent.length === 0) {
    recentActivityEl.innerHTML = '<p>No recent activity</p>';
    clientLog.info('No recent activity entries found', 'RecentActivity');
    return;
  }

  // Debug the first few entries
  clientLog.debug('Recent activity entries available', 'RecentActivity');

  let html = '';
  recent.forEach((entry) => {
    const time = new Date(entry.timestamp).toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });

    // Create more descriptive message summary with proper truncation
    let msg = '';
    if (typeof entry.message === 'string') {
      // Extract filename for uploads
      if (
        entry.action === 'UPLOAD_GRAPHIC' &&
        entry.message.includes('File upload successful:')
      ) {
        const filename = entry.message
          .replace('File upload successful: ', '')
          .split(' (ID:')[0];
        msg = `Upload: ${filename}`;
      } else {
        msg = entry.message;
      }
    } else if (entry.action) {
      // Use action as fallback if available
      msg = `${entry.action}`;
    } else {
      msg = 'System event';
    }

    // Use CSS instead of truncating the text - allows for tooltip on hover
    html += `
      <div class="activity-item">
        <span class="activity-time">${time}</span>
        <span class="activity-message" title="${escapeHtml(msg)}">${msg}</span>
      </div>
    `;
  });

  recentActivityEl.innerHTML = html;
}

function updateCurrentUserModule() {
  const currentUserEl = document.getElementById('currentUser');
  if (!currentUserEl) return;

  // Get initials for the avatar
  const initials = currentUser.name
    .split(' ')
    .map((name) => name.charAt(0))
    .join('')
    .toUpperCase();

  // Start with the user info
  let html = `
    <div class="user-info">
      <div class="user-header">
        <div class="user-avatar">${initials}</div>
        <div class="user-name">${currentUser.name}</div>
      </div>
      <div class="user-details">
        @${currentUser.username} <span class="user-id">(${currentUser.id})</span>
        ${currentUser.roles.map((role) => `<span class="user-role">${role}</span>`).join('')}
      </div>
    </div>
  `;

  // Add owned files section
  html += `<div class="user-files">
    <strong>Owned Files:</strong>
    <ul class="file-list">`;

  // Get recent uploads from this user with improved filtering
  // Use a Map to deduplicate files by their resourceId
  const fileMap = new Map();

  // First collect all file events
  const fileEvents = auditEntries.filter(
    (entry) =>
      entry.userId === currentUser.id && entry.action === 'UPLOAD_GRAPHIC',
  );

  // Process file events into a map to deduplicate and track events
  fileEvents.forEach((entry) => {
    if (!entry.resourceId) return;

    const fileName =
      entry.message && typeof entry.message === 'string'
        ? entry.message
            .replace('File upload successful: ', '')
            .split(' (ID:')[0]
        : `File-${entry.resourceId}`;

    // If this file ID already exists in the map, just add this event to its history
    if (fileMap.has(entry.resourceId)) {
      const fileInfo = fileMap.get(entry.resourceId);
      fileInfo.events.push({
        timestamp: entry.timestamp,
        status: entry.status,
        action: entry.action,
        message:
          typeof entry.message === 'string' ? entry.message : 'File operation',
      });
      // Sort events by timestamp (newest first)
      fileInfo.events.sort(
        (a, b) => new Date(b.timestamp) - new Date(a.timestamp),
      );
    } else {
      // Create a new file entry with this event
      fileMap.set(entry.resourceId, {
        id: entry.resourceId,
        name: fileName,
        latestEvent: new Date(entry.timestamp),
        events: [
          {
            timestamp: entry.timestamp,
            status: entry.status,
            action: entry.action,
            message:
              typeof entry.message === 'string'
                ? entry.message
                : 'File operation',
          },
        ],
      });
    }
  });

  // Convert map to array and sort by latest event timestamp
  const uniqueFiles = Array.from(fileMap.values())
    .sort((a, b) => b.latestEvent - a.latestEvent)
    .slice(0, 5); // Show only the 5 most recent files

  // Update user's files array for other functions to use
  currentUser.files = uniqueFiles;

  clientLog.info(
    `Found ${uniqueFiles.length} unique files for user ${currentUser.name}`,
    'UserModule',
  );

  if (uniqueFiles.length === 0) {
    html += `<li class="file-item">No files found</li>`;
  } else {
    uniqueFiles.forEach((file) => {
      const latestEventDate = new Date(file.latestEvent).toLocaleString([], {
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
      });

      // Count number of events for this file
      const numEvents = file.events.length;

      html += `
        <li class="file-item" data-file-id="${file.id}">
          <span class="file-name" title="${file.name}">${file.name}</span>
          <span class="file-date">${latestEventDate}</span>
          <span class="file-actions">
            <span class="file-event-count" title="Click to view file history">${numEvents} ${numEvents === 1 ? 'event' : 'events'}</span>
          </span>
          <div class="file-events hidden">
            ${file.events
              .map((event) => {
                const eventTime = new Date(event.timestamp).toLocaleString([], {
                  month: '2-digit',
                  day: '2-digit',
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit',
                });
                const statusClass = event.status ? `event-${event.status}` : '';
                return `
                <div class="file-event ${statusClass}">
                  <span class="event-time">${eventTime}</span>
                  <span class="event-action">${event.action}</span>
                  <span class="event-status">${event.status || ''}</span>
                </div>
              `;
              })
              .join('')}
          </div>
        </li>`;
    });
  }

  html += `</ul></div>`;

  // Set the HTML
  currentUserEl.innerHTML = html;

  // Add click handlers for file events toggle
  const fileItems = currentUserEl.querySelectorAll('.file-item');
  fileItems.forEach((item) => {
    const eventCount = item.querySelector('.file-event-count');
    const eventsDiv = item.querySelector('.file-events');

    if (eventCount && eventsDiv) {
      eventCount.addEventListener('click', (e) => {
        e.stopPropagation();
        eventsDiv.classList.toggle('hidden');

        // Close other open event lists
        fileItems.forEach((otherItem) => {
          if (otherItem !== item) {
            const otherEventsDiv = otherItem.querySelector('.file-events');
            if (otherEventsDiv) {
              otherEventsDiv.classList.add('hidden');
            }
          }
        });
      });
    }
  });
}

// ----------- Helper Functions -----------

function escapeHtml(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function highlightLogFromAudit(logId) {
  // Find the corresponding full log entry
  const logElements = logContainer.querySelectorAll('.log-entry');
  let foundElement = null;

  logElements.forEach((el) => {
    // Remove highlight from all entries
    el.classList.remove('highlight-log');

    // If this is our target entry, mark it
    if (el.dataset.logId === logId) {
      foundElement = el;
    }
  });

  // If we found the element, highlight and scroll to it
  if (foundElement) {
    foundElement.classList.add('highlight-log');
    foundElement.scrollIntoView({
      behavior: 'smooth',
      block: 'center',
    });
  }
}

function showLogOverlay(details) {
  const overlay = document.getElementById('logOverlay');
  const logDetailsElement = document.getElementById('logDetails');
  const closeOverlayBtn = document.getElementById('closeOverlay');

  if (!overlay || !logDetailsElement || !closeOverlayBtn) {
    console.error('Overlay elements not found');
    return;
  }

  logDetailsElement.innerHTML = details;
  overlay.classList.remove('hidden');

  // Close overlay when clicking the close button
  closeOverlayBtn.addEventListener('click', () => {
    overlay.classList.add('hidden');
  });

  // Close overlay when clicking outside the content
  overlay.addEventListener('click', (event) => {
    if (event.target === overlay) {
      overlay.classList.add('hidden');
    }
  });
}

function checkGraphicsRoute(id) {
  if (!id) {
    console.warn('Invalid graphic ID provided for route check.');
    return;
  }

  fetch(`/graphics/${id}`)
    .then((response) => {
      if (response.ok) {
        console.log(`Graphic with ID ${id} retrieved successfully.`);
      } else {
        console.error(
          `Failed to retrieve graphic with ID ${id}. Status: ${response.status} - ${response.statusText}`,
        );
      }
    })
    .catch((error) => {
      console.error(
        `Error checking graphic route for ID ${id}: ${error.message}`,
      );
    });
}

function setupAutoRefresh() {
  const timeRange = document.getElementById('timeRange')?.value || '5min';
  let refreshInterval;

  // Set different refresh intervals based on the time range
  switch (timeRange) {
    case '5min':
      refreshInterval = 10000; // Refresh every 10 seconds for 5-minute view
      break;
    case 'hour':
      refreshInterval = 30000; // Refresh every 30 seconds for hour view
      break;
    default:
      refreshInterval = 60000; // Refresh every minute for other views
  }

  // Clear any existing interval
  if (window.logRefreshInterval) {
    clearInterval(window.logRefreshInterval);
  }

  // Set up the new refresh interval
  window.logRefreshInterval = setInterval(() => {
    if (!isStreaming) {
      // Only refresh if not streaming
      fetchLogs();
    }
  }, refreshInterval);
}

// ----------- Client-side Logging Functions -----------

/**
 * Client-side logger function that uses the API endpoint to log messages
 * Enhanced with connection state tracking and retry logic
 */
function clientLogger(message, level = 2, context = 'ViewerClient') {
  // Don't log debug messages in production
  if (level === 0 && window.location.hostname !== 'localhost') {
    return;
  }

  // Connection state tracking
  if (!window.loggerState) {
    window.loggerState = {
      connectionFailed: false,
      failedAttempts: 0,
      maxFailedAttempts: 3,
      lastFailure: 0,
      backoffTime: 5000, // Start with 5 second backoff
      maxBackoff: 60000, // Maximum 1 minute backoff
    };
  }

  // Check if we should avoid sending logs due to persistent failures
  const now = Date.now();
  if (window.loggerState.connectionFailed) {
    // If we've had failures, only retry after backoff time has passed
    if ((now - window.loggerState.lastFailure) < window.loggerState.backoffTime) {
      // Only log to console for important messages during backoff
      if (level >= 3) { // WARN or ERROR
        const levelName = ['DEBUG', 'INFO', 'LOG', 'WARN', 'ERROR'][level] || 'UNKNOWN';
        console.warn(`[${levelName}] [${context}] ${JSON.stringify(message)} (server logging disabled due to connection issues)`);
      }
      return; // Skip sending to server during backoff period
    }
  }

  // Ensure level is numeric - convert from string if needed
  if (typeof level === 'string') {
    level = stringToLogLevel(level);
  }

  // Create a log payload
  const logPayload = {
    message: message,
    level: level, // Ensure this is a number
    context: context,
  };

  // Use absolute URL path instead of relative path to avoid incorrect resolution
  fetch('/logs', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Client-Source': 'viewer.js',
    },
    body: JSON.stringify(logPayload),
  })
  .then(() => {
    // Reset connection state on success
    if (window.loggerState.connectionFailed) {
      window.loggerState.connectionFailed = false;
      window.loggerState.failedAttempts = 0;
      window.loggerState.backoffTime = 5000;
      console.info('Log server connection restored');
    }
  })
  .catch((err) => {
    // Track connection failures with exponential backoff
    window.loggerState.failedAttempts++;
    window.loggerState.lastFailure = now;
    
    if (window.loggerState.failedAttempts >= window.loggerState.maxFailedAttempts) {
      if (!window.loggerState.connectionFailed) {
        console.warn(`Logging server appears to be down. Temporarily disabling client logs after ${window.loggerState.failedAttempts} failed attempts.`);
        window.loggerState.connectionFailed = true;
      }
      
      // Implement exponential backoff
      window.loggerState.backoffTime = Math.min(
        window.loggerState.backoffTime * 2,
        window.loggerState.maxBackoff
      );
    }
    
    // Only log the error to console once to avoid cascading
    if (window.loggerState.failedAttempts <= window.loggerState.maxFailedAttempts) {
      console.error('Failed to send log to server:', err);
    }
  });
}

/**
 * Convert string log level names to their numeric values
 */
function stringToLogLevel(levelName) {
  if (typeof levelName !== 'string') return levelName;
  
  switch (levelName.toUpperCase()) {
    case 'DEBUG': return 0;
    case 'INFO': return 1;
    case 'LOG': return 2;
    case 'WARN': return 3;
    case 'ERROR': return 4;
    default: return 2; // Default to LOG level
  }
}

// Convenience methods for different log levels (with numeric values)
const clientLog = {
  debug: (msg, context) => clientLogger(msg, 0, context),
  info: (msg, context) => clientLogger(msg, 1, context),
  log: (msg, context) => clientLogger(msg, 2, context),
  warn: (msg, context) => clientLogger(msg, 3, context),
  error: (msg, context) => clientLogger(msg, 4, context),
  // New method specifically for UI/UX events - using numeric level
  uiEvent: (action, element, details) =>
    clientLogger(
      {
        action: action,
        element: element,
        details: details,
        timestamp: new Date().toISOString(),
        url: window.location.pathname,
        viewportWidth: window.innerWidth,
        viewportHeight: window.innerHeight,
      },
      1, // INFO level (numeric)
      'UI/UX', // Special context for UI events
    ),
};

// Function to track UI interactions
function trackUIEvent(action, element, details = {}) {
  clientLog.uiEvent(action, element, details);
}

// Function to setup click tracking on important UI elements
function setupUITracking() {
  // Track clicks on the entire document but filter for important elements
  document.addEventListener('click', (event) => {
    // Find the nearest clickable element (button, link, etc.)
    const element = event.target.closest(
      'button, .file-item, .audit-entry, .log-entry, .activity-item, select, .file-event-count',
    );

    if (!element) return; // Not an important element

    // Get element information
    const elementType = element.tagName.toLowerCase();
    const elementId = element.id || '';
    const elementClass = Array.from(element.classList).join(' ');
    const elementText = element.textContent?.trim().substring(0, 30) || '';

    // Determine action based on element type
    let action = 'clicked';
    if (elementType === 'button') {
      action = 'button_click';
    } else if (element.classList.contains('log-entry')) {
      action = 'log_entry_click';
    } else if (element.classList.contains('audit-entry')) {
      action = 'audit_entry_click';
    } else if (element.classList.contains('file-item')) {
      action = 'file_item_click';
    } else if (element.classList.contains('file-event-count')) {
      action = 'file_event_toggle';
    } else if (elementType === 'select') {
      action = 'filter_change';
    }

    // Track the event
    trackUIEvent(
      action,
      {
        type: elementType,
        id: elementId,
        class: elementClass,
        text: elementText,
      },
      {
        x: event.clientX,
        y: event.clientY,
        timestamp: new Date().toISOString(),
      },
    );
  });

  // Also track filter changes
  const filterElements = document.querySelectorAll(
    'select, input[type="text"]',
  );
  filterElements.forEach((element) => {
    element.addEventListener('change', (event) => {
      const elementId = event.target.id || '';
      const value = event.target.value;

      trackUIEvent(
        'filter_change',
        {
          type: event.target.tagName.toLowerCase(),
          id: elementId,
        },
        {
          value: value,
          timestamp: new Date().toISOString(),
        },
      );
    });
  });
}

// Add a function to verify the log streaming is working
function verifyLogStreaming() {
  // Check if we have an active EventSource connection
  const isConnected = evtSource && evtSource.readyState === EventSource.OPEN;
  console.log(`Log streaming connection check: ${isConnected ? 'CONNECTED' : 'DISCONNECTED'}`);
  
  // Log the current log count
  console.log(`Current log count: ${logCount}`);
  
  // If not connected, try to reconnect
  if (!isConnected && !isStreaming) {
    console.log("Log streaming not active, attempting to start...");
    startStreaming();
  }
  
  return isConnected;
}

// Add a self-diagnostic check for the log viewer
function runLogViewerDiagnostics() {
  console.log("Running log viewer diagnostics...");
  
  // Check if log container exists
  if (!logContainer) {
    console.error("CRITICAL: Log container element not found in DOM!");
  } else {
    console.log(`Log container found, contains ${logContainer.children.length} entries`);
  }
  
  // Check streaming status
  const streamingActive = verifyLogStreaming();
  
  // Check if we can insert logs manually
  try {
    const testLog = {
      id: `test-${Date.now()}`,
      level: 1,
      message: "Log viewer diagnostic test entry",
      context: "Diagnostics",
      timestamp: new Date()
    };
    const logElement = addLogEntry(testLog);
    console.log("Successfully added test log entry to UI");
    
    // Remove test entry after verification
    setTimeout(() => {
      if (logElement && logElement.parentNode) {
        logElement.parentNode.removeChild(logElement);
        logCount--;
        updateLogCount();
      }
    }, 5000);
  } catch (err) {
    console.error("Failed to add test log entry:", err);
  }
  
  console.log("Diagnostic results:", {
    logContainerFound: !!logContainer,
    streamingActive,
    currentLogCount: logCount
  });
}

// Run diagnostics after a short delay to allow initial setup
setTimeout(runLogViewerDiagnostics, 3000);

// Add a periodic check to verify streaming is working
setInterval(verifyLogStreaming, 30000);

// Check if logContainer exists before continuing
if (!logContainer) {
  console.error('Log container element not found! Check your HTML structure.');
}

// Add test buttons for each log level to help diagnose the issue
function addTestLogButtons() {
  const buttonRow = document.querySelector('.button-row');
  if (!buttonRow) return;
  
  const testLogLevels = [
    { name: 'Debug', level: 0 },
    { name: 'Info', level: 1 },
    { name: 'Log', level: 2 },
    { name: 'Warn', level: 3 },
    { name: 'Error', level: 4 }
  ];
  
  testLogLevels.forEach(({ name, level }) => {
    const btn = document.createElement('button');
    btn.textContent = `Test ${name}`;
    btn.classList.add('test-log-btn');
    btn.style.backgroundColor = getColorForLevel(level);
    btn.style.marginLeft = '5px';
    btn.style.fontSize = '0.75em';
    
    btn.addEventListener('click', async () => {
      try {
        await fetch('/logs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            level: level,  // Send numeric level instead of string
            message: `Test ${name} message at ${new Date().toLocaleTimeString()}`,
            context: 'TestLogs'
          }),
        });
        console.log(`${name} log triggered`);
      } catch (error) {
        console.error(`Failed to trigger ${name} log:`, error);
      }
    });
    
    buttonRow.appendChild(btn);
  });
}

function getColorForLevel(level) {
  switch (parseInt(level)) {
    case 0: return '#2196f3'; // Debug - Blue
    case 1: return '#4caf50'; // Info - Green
    case 2: return '#9e9e9e'; // Log - Gray
    case 3: return '#ffc107'; // Warn - Yellow/Amber
    case 4: return '#f44336'; // Error - Red
    default: return '#9e9e9e';
  }
}

// Initialize the application when the DOM is loaded
document.addEventListener('DOMContentLoaded', initLogViewer);
